<?php
/**
 * WP-CLI: import bundled v6 Bricks JSON into bricks_template posts.
 */
defined('ABSPATH') || exit;

if (!defined('WP_CLI') || !WP_CLI || !class_exists('WP_CLI', false)) {
	return;
}

/**
 * Map export "content" array + Bricks template type to the correct post meta key.
 *
 * @return array{0:string,1:string} [ meta_key, template_type ]
 */
function profuzion_bricks_meta_for_import(string $basename): array {
	switch ($basename) {
		case 'profuzion-v6-bricks-header-import.json':
			return ['_bricks_page_header_2', 'header'];
		case 'profuzion-v6-bricks-footer-import.json':
			return ['_bricks_page_footer_2', 'footer'];
		case 'profuzion-v6-bricks-home-import.json':
			return ['_bricks_page_content_2', 'content'];
		case 'profuzion-v6-bricks-case-import.json':
			return ['_bricks_page_content_2', 'content'];
		case 'profuzion-v6-bricks-hero-prompt-import.json':
			return ['_bricks_page_content_2', 'content'];
		default:
			WP_CLI::error("Unknown import file: {$basename}");
	}
}

/**
 * @param array<int,mixed> $elements
 */
function profuzion_bricks_clear_stale_template_meta(int $post_id, string $primary_key): void {
	$keys = ['_bricks_page_header_2', '_bricks_page_footer_2', '_bricks_page_content_2'];
	foreach ($keys as $k) {
		if ($k !== $primary_key) {
			delete_post_meta($post_id, $k);
		}
	}
}

/**
 * @param array<int,mixed> $elements
 */
function profuzion_bricks_upsert_template(string $slug, string $title, string $template_type, string $meta_key, array $elements, bool $dry_run): int {
	if (!post_type_exists('bricks_template')) {
		WP_CLI::error('Post type bricks_template is not registered. Activate the Bricks parent theme.');
	}

	$existing = get_posts(
		[
			'post_type'              => 'bricks_template',
			'name'                   => $slug,
			'post_status'            => 'any',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
		]
	);

	$post_id = isset($existing[0]) ? (int) $existing[0] : 0;

	if ($dry_run) {
		WP_CLI::log(($post_id ? 'Would update' : 'Would create') . " template slug={$slug} type={$template_type}");
		return $post_id > 0 ? $post_id : 0;
	}

	if ($post_id) {
		wp_update_post(
			[
				'ID'           => $post_id,
				'post_title'   => $title,
				'post_status'  => 'publish',
				'post_name'    => $slug,
				'post_type'    => 'bricks_template',
			]
		);
	} else {
		$post_id = (int) wp_insert_post(
			[
				'post_title'  => $title,
				'post_status' => 'publish',
				'post_name'   => $slug,
				'post_type'   => 'bricks_template',
			],
			true
		);
		if (!$post_id || is_wp_error($post_id)) {
			WP_CLI::error(is_wp_error($post_id) ? $post_id->get_error_message() : 'wp_insert_post failed');
		}
	}

	update_post_meta($post_id, '_bricks_template_type', $template_type);
	profuzion_bricks_clear_stale_template_meta($post_id, $meta_key);
	update_post_meta($post_id, $meta_key, $elements);

	return $post_id;
}

WP_CLI::add_command(
	'profuzion import-bricks',
	static function (array $args, array $assoc_args): void {
		$dry_run = isset($assoc_args['dry-run']);
		$dir     = trailingslashit(get_stylesheet_directory()) . 'bricks-import';

		if (!is_dir($dir)) {
			WP_CLI::error("Missing directory: {$dir}. Run npm run wp:handoff and redeploy the child theme.");
		}

		$map = [
			'profuzion-v6-bricks-header-import.json'         => ['slug' => 'pfz-v6-header', 'title' => 'Profuzion v6 · Header'],
			'profuzion-v6-bricks-footer-import.json'         => ['slug' => 'pfz-v6-footer', 'title' => 'Profuzion v6 · Footer'],
			'profuzion-v6-bricks-home-import.json'           => ['slug' => 'pfz-v6-home', 'title' => 'Profuzion v6 · Home'],
			'profuzion-v6-bricks-hero-prompt-import.json' => ['slug' => 'pfz-v6-hero-prompt', 'title' => 'Profuzion v6 · Hero (class-toggle prompt)'],
			'profuzion-v6-bricks-case-import.json'           => ['slug' => 'pfz-v6-case', 'title' => 'Profuzion v6 · Case study'],
		];

		foreach ($map as $file => $info) {
			$path = $dir . '/' . $file;
			if (!is_readable($path)) {
				WP_CLI::error("Missing or unreadable: {$path}");
			}
			$raw = file_get_contents($path);
			if ($raw === false) {
				WP_CLI::error("Could not read: {$path}");
			}
			$data = json_decode($raw, true);
			if (!is_array($data) || empty($data['content']) || !is_array($data['content'])) {
				WP_CLI::error("Invalid Bricks JSON (expected content array): {$file}");
			}
			list($meta_key, $template_type) = profuzion_bricks_meta_for_import($file);

			$pid = profuzion_bricks_upsert_template(
				$info['slug'],
				$info['title'],
				$template_type,
				$meta_key,
				$data['content'],
				$dry_run
			);

			if (!$dry_run) {
				WP_CLI::log("Imported {$file} → ID {$pid} ({$info['slug']})");
			}
		}

		if (!$dry_run) {
			WP_CLI::success('Profuzion Bricks templates imported. Set a static homepage (optional) so pfz-v6-home applies when that page has no Bricks body.');
		}
	},
	[
		'shortdesc' => 'Import Profuzion v6 Bricks templates from the child theme bricks-import/ folder.',
	]
);

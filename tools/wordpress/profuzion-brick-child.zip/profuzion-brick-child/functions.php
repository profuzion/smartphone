<?php
/**
 * Profuzion — Bricks child theme (v6)
 *
 * WordPress loads only: this theme’s CSS/JS + Bricks/ACSS — not authoring-preview bundles from the design repository.
 */

defined('ABSPATH') || exit;

define('PROFUZION_BRICK_VER', '1.1.1');
define('PROFUZION_BRICK_DIR', get_stylesheet_directory());
define('PROFUZION_BRICK_URI', get_stylesheet_directory_uri());

/** Load GSAP / Three from /assets/js/vendor/ (see sync-wp-vendor-js in project scripts). If false, uses CDN fallbacks. */
define('PROFUZION_VENDOR_LOCAL', true);

/** WebGL halftone + pfz-halftone-hero.js — usually homepage only. Filter: profuzion_enqueue_halftone */
define('PROFUZION_V6_HALFTONE_DEFAULT', true);

/** ScrollTrigger layer for hero / industries (safe on all templates; no-ops if nodes missing). */
define('PROFUZION_V6_SCROLL_ANIMS', true);

require_once PROFUZION_BRICK_DIR . '/includes/cpt-case-study.php';
require_once PROFUZION_BRICK_DIR . '/includes/bricks-auto-templates.php';

if (defined('WP_CLI') && WP_CLI) {
	require_once PROFUZION_BRICK_DIR . '/includes/wp-cli-profz.php';
}

add_action('after_switch_theme', static function (): void {
	flush_rewrite_rules();
});

add_filter('body_class', function (array $classes): array {
	$classes[] = 'pfz';
	$classes[] = 'pfz-v6';
	return $classes;
});

/**
 * Whether to enqueue the Three.js hero halftone (heavy).
 *
 * When PROFUZION_V6_HALFTONE_DEFAULT is true: defaults to the site front page only (see `is_front_page()`).
 * Always filterable via `profuzion_enqueue_halftone` (pass a boolean).
 */
function profuzion_should_enqueue_halftone(): bool {
	if (!PROFUZION_V6_HALFTONE_DEFAULT) {
		return (bool) apply_filters('profuzion_enqueue_halftone', false);
	}

	return (bool) apply_filters('profuzion_enqueue_halftone', is_front_page());
}

add_action('wp_enqueue_scripts', function (): void {
	if (is_admin()) {
		return;
	}
	$ver = PROFUZION_BRICK_VER;

	$style_deps = [];
	$wp_styles = wp_styles();
	if (isset($wp_styles->registered['bricks-frontend-css'])) {
		$style_deps[] = 'bricks-frontend-css';
	}

	wp_enqueue_style(
		'profuzion-v6-bundled',
		PROFUZION_BRICK_URI . '/assets/css/profuzion-v6-wp-bundled.css',
		$style_deps,
		$ver
	);

	wp_enqueue_script(
		'profuzion-cursor',
		PROFUZION_BRICK_URI . '/assets/js/cursor.js',
		[],
		$ver,
		true
	);

	$vendor_dir = PROFUZION_BRICK_DIR . '/assets/js/vendor';
	$gsap_path = $vendor_dir . '/gsap.min.js';
	$st_path = $vendor_dir . '/ScrollTrigger.min.js';
	$three_path = $vendor_dir . '/three.min.js';
	$use_vendor = defined('PROFUZION_VENDOR_LOCAL') && PROFUZION_VENDOR_LOCAL
		&& file_exists($gsap_path) && file_exists($st_path);

	if ($use_vendor) {
		wp_register_script(
			'gsap',
			PROFUZION_BRICK_URI . '/assets/js/vendor/gsap.min.js',
			[],
			(string) filemtime($gsap_path),
			true
		);
		wp_register_script(
			'gsap-scrolltrigger',
			PROFUZION_BRICK_URI . '/assets/js/vendor/ScrollTrigger.min.js',
			['gsap'],
			(string) filemtime($st_path),
			true
		);
	} else {
		wp_register_script(
			'gsap',
			'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.15.0/gsap.min.js',
			[],
			'3.15.0',
			true
		);
		wp_register_script(
			'gsap-scrolltrigger',
			'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.15.0/ScrollTrigger.min.js',
			['gsap'],
			'3.15.0',
			true
		);
	}

	wp_enqueue_script('gsap');
	wp_enqueue_script('gsap-scrolltrigger');
	wp_enqueue_script(
		'profuzion-motion',
		PROFUZION_BRICK_URI . '/assets/js/motion.js',
		['gsap', 'gsap-scrolltrigger'],
		$ver,
		true
	);

	if (PROFUZION_V6_SCROLL_ANIMS) {
		wp_enqueue_script(
			'pfz-v6-animations',
			PROFUZION_BRICK_URI . '/assets/js/pfz-v6-animations.js',
			['gsap', 'gsap-scrolltrigger'],
			$ver,
			true
		);
	}

	if (profuzion_should_enqueue_halftone()) {
		$three_ok = $use_vendor && file_exists($three_path);
		if ($three_ok) {
			wp_enqueue_script(
				'three',
				PROFUZION_BRICK_URI . '/assets/js/vendor/three.min.js',
				[],
				(string) filemtime($three_path),
				true
			);
		} else {
			wp_enqueue_script(
				'three',
				'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js',
				[],
				'0.160.0',
				true
			);
		}
		wp_enqueue_script(
			'pfz-halftone-hero',
			PROFUZION_BRICK_URI . '/assets/js/pfz-halftone-hero.js',
			['three'],
			$ver,
			true
		);
	}
}, 20);
